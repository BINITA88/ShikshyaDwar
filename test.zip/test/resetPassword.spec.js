import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import ResetPassword from '../src/pages/userpages/ResetPassword';
import { rest } from 'msw';
import { setupServer } from 'msw/node';

// Mock API server
const server = setupServer(
  rest.put('http://localhost:9000/api/resetpassword/:token', (req, res, ctx) => {
    const { token } = req.params;
    const { password } = req.body;

    if (token === 'valid-token' && password) {
      return res(ctx.status(200), ctx.json({ message: 'Password reset successfully.' }));
    }

    if (token === 'expired-token') {
      return res(ctx.status(400), ctx.json({ error: 'Invalid or expired token' }));
    }

    return res(ctx.status(500), ctx.json({ error: 'Internal server error' }));
  })
);

// Enable request interception
beforeAll(() => server.listen());
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

describe('ResetPassword Component', () => {
  test('should successfully reset password with a valid token', async () => {
    render(
      <MemoryRouter initialEntries={['/resetpassword/valid-token']}>
        <Routes>
          <Route path="/resetpassword/:token" element={<ResetPassword />} />
        </Routes>
      </MemoryRouter>
    );

    fireEvent.change(screen.getByPlaceholderText(/Enter new password/i), { target: { value: 'NewPass@123' } });
    fireEvent.change(screen.getByPlaceholderText(/Confirm your password/i), { target: { value: 'NewPass@123' } });

    fireEvent.click(screen.getByRole('button', { name: /reset password/i }));

    await waitFor(() => {
      expect(screen.getByText(/Password reset successfully/i)).toBeInTheDocument();
    });
  });

  test('should show an error when passwords do not match', async () => {
    render(
      <MemoryRouter initialEntries={['/resetpassword/valid-token']}>
        <Routes>
          <Route path="/resetpassword/:token" element={<ResetPassword />} />
        </Routes>
      </MemoryRouter>
    );

    fireEvent.change(screen.getByPlaceholderText(/Enter new password/i), { target: { value: 'NewPass@123' } });
    fireEvent.change(screen.getByPlaceholderText(/Confirm your password/i), { target: { value: 'DifferentPass@456' } });

    fireEvent.click(screen.getByRole('button', { name: /reset password/i }));

    expect(screen.getByText(/Passwords do not match/i)).toBeInTheDocument();
  });

  test('should show an error when API fails', async () => {
    server.use(
      rest.put('http://localhost:9000/api/resetpassword/:token', (req, res, ctx) => {
        return res(ctx.status(500), ctx.json({ error: 'Internal server error' }));
      })
    );

    render(
      <MemoryRouter initialEntries={['/resetpassword/valid-token']}>
        <Routes>
          <Route path="/resetpassword/:token" element={<ResetPassword />} />
        </Routes>
      </MemoryRouter>
    );

    fireEvent.change(screen.getByPlaceholderText(/Enter new password/i), { target: { value: 'NewPass@123' } });
    fireEvent.change(screen.getByPlaceholderText(/Confirm your password/i), { target: { value: 'NewPass@123' } });

    fireEvent.click(screen.getByRole('button', { name: /reset password/i }));

    await waitFor(() => {
      expect(screen.getByText(/An error occurred. Please try again./i)).toBeInTheDocument();
    });
  });

  test('should show an error when token is invalid or expired', async () => {
    render(
      <MemoryRouter initialEntries={['/resetpassword/expired-token']}>
        <Routes>
          <Route path="/resetpassword/:token" element={<ResetPassword />} />
        </Routes>
      </MemoryRouter>
    );

    fireEvent.change(screen.getByPlaceholderText(/Enter new password/i), { target: { value: 'NewPass@123' } });
    fireEvent.change(screen.getByPlaceholderText(/Confirm your password/i), { target: { value: 'NewPass@123' } });

    fireEvent.click(screen.getByRole('button', { name: /reset password/i }));

    await waitFor(() => {
      expect(screen.getByText(/Invalid or expired token/i)).toBeInTheDocument();
    });
  });
});
