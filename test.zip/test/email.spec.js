import { test, expect } from '@playwright/test';

test.describe('API Email Verification Endpoint', () => {

  // ✅ Test for successful email verification
  test('should verify email successfully with a valid token', async ({ request }) => {
    const validToken = 'VALID_TEST_TOKEN'; // Replace with an actual valid token

    const response = await request.post(`http://localhost:9000/api/confirmation/${validToken}`);

    const rawResponse = await response.text();
    console.log('Raw Response:', rawResponse);

    try {
      const responseBody = JSON.parse(rawResponse);
      console.log('Response JSON:', responseBody);

      expect(response.status()).toBe(200);
      expect(responseBody).toHaveProperty('success', true);
      expect(responseBody).toHaveProperty('message', 'Email has been successfully verified.');
    } catch (error) {
      console.error('❌ Error parsing JSON:', error);
      throw new Error(`Invalid JSON response: ${rawResponse}`);
    }
  });

  // ❌ Test for invalid or expired token
  test('should return an error for an invalid or expired token', async ({ request }) => {
    const invalidToken = 'INVALID_OR_EXPIRED_TOKEN';

    const response = await request.post(`http://localhost:9000/api/confirmation/${invalidToken}`);
    
    const rawResponse = await response.text();
    console.log('Raw Response:', rawResponse);

    try {
      const responseBody = JSON.parse(rawResponse);
      console.log('Response JSON:', responseBody);

      expect([400, 401]).toContain(response.status());
      expect(responseBody).toHaveProperty('success', false);
      expect(responseBody).toHaveProperty('error', 'Invalid or expired verification token.');
    } catch (error) {
      console.error('❌ Error parsing JSON:', error);
      throw new Error(`Invalid JSON response: ${rawResponse}`);
    }
  });

  // ❌ Test for missing token
  test('should return an error if the token is missing', async ({ request }) => {
    const response = await request.post(`http://localhost:9000/api/confirmation/`);

    const rawResponse = await response.text();
    console.log('Raw Response:', rawResponse);

    try {
      const responseBody = JSON.parse(rawResponse);
      console.log('Response JSON:', responseBody);

      expect(response.status()).toBe(400);
      expect(responseBody).toHaveProperty('success', false);
      expect(responseBody).toHaveProperty('error', 'Verification token is required.');
    } catch (error) {
      console.error('❌ Error parsing JSON:', error);
      throw new Error(`Invalid JSON response: ${rawResponse}`);
    }
  });

});
